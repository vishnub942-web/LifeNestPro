package com.vishnu.lifenest.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.vishnu.lifenest.data.entity.Task

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks WHERE date = :date ORDER BY id ASC")
    fun getTasksForDate(date: String): LiveData<List<Task>>

    @Query("SELECT * FROM tasks WHERE date LIKE :monthPrefix || '%' ORDER BY name, date")
    suspend fun getTasksForMonth(monthPrefix: String): List<Task>

    @Query("SELECT DISTINCT name FROM tasks ORDER BY name")
    fun getAllTaskNames(): LiveData<List<String>>

    @Query("SELECT DISTINCT name FROM tasks ORDER BY name")
    suspend fun getAllTaskNamesOnce(): List<String>

    @Insert
    suspend fun insert(task: Task): Long

    @Update
    suspend fun update(task: Task)

    @Delete
    suspend fun delete(task: Task)

    @Query("DELETE FROM tasks WHERE name = :name")
    suspend fun deleteAllWithName(name: String)

    @Query("SELECT * FROM tasks WHERE name = :name AND date = :date LIMIT 1")
    suspend fun findByNameAndDate(name: String, date: String): Task?
}
