package com.vishnu.lifenest.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.vishnu.lifenest.data.dao.*
import com.vishnu.lifenest.data.entity.*

@Database(
    entities = [Task::class, TodoItem::class, Note::class, Birthday::class, Transaction::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    abstract fun todoDao(): TodoDao
    abstract fun noteDao(): NoteDao
    abstract fun birthdayDao(): BirthdayDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lifenest_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
