package com.vishnu.lifenest.ui.more

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.vishnu.lifenest.R
import com.vishnu.lifenest.databinding.FragmentMoreMenuBinding
import com.vishnu.lifenest.ui.birthday.BirthdayFragment
import com.vishnu.lifenest.ui.debitcredit.DebitCreditFragment

// Simple hub screen: since bottom nav only fits 5 tabs, Birthday and
// Debit/Credit live under this "More" tab as two buttons.
class MoreMenuFragment : Fragment() {

    private var _binding: FragmentMoreMenuBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoreMenuBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBirthday.setOnClickListener {
            openInner(BirthdayFragment())
        }
        binding.btnDebitCredit.setOnClickListener {
            openInner(DebitCreditFragment())
        }
    }

    // Opens the chosen screen inside the same container, on top of this menu.
    private fun openInner(fragment: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
