package com.vishnu.lifenest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.vishnu.lifenest.databinding.ActivityMainBinding
import com.vishnu.lifenest.ui.birthday.BirthdayFragment
import com.vishnu.lifenest.ui.calendar.CalendarFragment
import com.vishnu.lifenest.ui.debitcredit.DebitCreditFragment
import com.vishnu.lifenest.ui.home.HomeFragment
import com.vishnu.lifenest.ui.notepad.NotepadFragment
import com.vishnu.lifenest.ui.todo.TodoFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            openFragment(HomeFragment())
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_calendar -> CalendarFragment()
                R.id.nav_todo -> TodoFragment()
                R.id.nav_notepad -> NotepadFragment()
                R.id.nav_more -> MoreMenuFragment()
                else -> HomeFragment()
            }
            openFragment(fragment)
            true
        }
    }

    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
