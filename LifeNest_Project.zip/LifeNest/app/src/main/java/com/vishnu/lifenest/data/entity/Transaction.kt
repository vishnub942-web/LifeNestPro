package com.vishnu.lifenest.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val personName: String,
    val amount: Double,
    val type: String,       // "DEBIT" or "CREDIT"
    val date: String,       // "2026-07-15"
    val remark: String = ""
)
