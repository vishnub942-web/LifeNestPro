package com.vishnu.lifenest.ui.debitcredit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.vishnu.lifenest.R
import com.vishnu.lifenest.databinding.FragmentDebitCreditBinding

class DebitCreditFragment : Fragment() {

    private var _binding: FragmentDebitCreditBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DebitCreditViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDebitCreditBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = TransactionAdapter(onDelete = { viewModel.deleteTransaction(it) })
        binding.recyclerTransactions.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerTransactions.adapter = adapter

        viewModel.allTransactions.observe(viewLifecycleOwner) { adapter.submitList(it) }

        viewModel.netBalance.observe(viewLifecycleOwner) { balance ->
            binding.tvNetBalance.text = if (balance >= 0)
                "Net: +%.2f (owed to you)".format(balance)
            else
                "Net: %.2f (you owe)".format(balance)
        }

        binding.fabAddTransaction.setOnClickListener { showAddDialog() }
    }

    private fun showAddDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_new_transaction, null)
        val etName = dialogView.findViewById<android.widget.EditText>(R.id.etPersonName)
        val etAmount = dialogView.findViewById<android.widget.EditText>(R.id.etAmount)
        val etRemark = dialogView.findViewById<android.widget.EditText>(R.id.etTransRemark)
        val radioGroup = dialogView.findViewById<android.widget.RadioGroup>(R.id.radioGroupType)

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Add Transaction")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim()
                val amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0
                val remark = etRemark.text.toString()
                val type = if (radioGroup.checkedRadioButtonId == R.id.radioCredit) "CREDIT" else "DEBIT"
                if (name.isNotEmpty() && amount > 0) {
                    viewModel.addTransaction(name, amount, type, remark)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
