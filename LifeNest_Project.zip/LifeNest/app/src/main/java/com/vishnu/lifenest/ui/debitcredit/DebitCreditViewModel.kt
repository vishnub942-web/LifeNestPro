package com.vishnu.lifenest.ui.debitcredit

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.map
import androidx.lifecycle.viewModelScope
import com.vishnu.lifenest.data.AppDatabase
import com.vishnu.lifenest.data.entity.Transaction
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class DebitCreditViewModel(application: Application) : AndroidViewModel(application) {

    private val transactionDao = AppDatabase.getDatabase(application).transactionDao()
    val allTransactions: LiveData<List<Transaction>> = transactionDao.getAll()

    // Positive = they owe you (net credit), Negative = you owe them (net debit)
    val netBalance: LiveData<Double> = allTransactions.map { list ->
        list.sumOf { if (it.type == "CREDIT") it.amount else -it.amount }
    }

    fun addTransaction(personName: String, amount: Double, type: String, remark: String) {
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            transactionDao.insert(
                Transaction(personName = personName, amount = amount, type = type, date = today, remark = remark)
            )
        }
    }

    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch { transactionDao.delete(transaction) }
    }
}
