package com.vishnu.lifenest.ui.calendar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.vishnu.lifenest.databinding.FragmentCalendarBinding
import java.text.SimpleDateFormat
import java.util.*

class CalendarFragment : Fragment() {

    private var _binding: FragmentCalendarBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CalendarViewModel by viewModels()

    private val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val monthFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
    private val monthDisplayFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCalendarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // --- Date view: pick a day, see that day's tasks ---
        val dayAdapter = DayTaskAdapter()
        binding.recyclerDayTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerDayTasks.adapter = dayAdapter

        binding.calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val cal = Calendar.getInstance()
            cal.set(year, month, dayOfMonth)
            val dateStr = dayFormat.format(cal.time)
            binding.tvSelectedDate.text = "Tasks on $dateStr"
            viewModel.loadTasksForDate(dateStr)
        }

        viewModel.selectedDateTasks.observe(viewLifecycleOwner) { tasks ->
            dayAdapter.submitList(tasks)
        }

        // Load today's tasks by default
        val today = dayFormat.format(Date())
        binding.tvSelectedDate.text = "Tasks on $today"
        viewModel.loadTasksForDate(today)

        // --- Month summary view ---
        val summaryAdapter = MonthSummaryAdapter()
        binding.recyclerMonthSummary.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerMonthSummary.adapter = summaryAdapter

        val monthCal = Calendar.getInstance()

        fun refreshMonthLabel() {
            binding.tvMonthLabel.text = monthDisplayFormat.format(monthCal.time)
            viewModel.loadMonthSummary(monthFormat.format(monthCal.time))
        }
        refreshMonthLabel()

        binding.btnPrevMonth.setOnClickListener {
            monthCal.add(Calendar.MONTH, -1)
            refreshMonthLabel()
        }
        binding.btnNextMonth.setOnClickListener {
            monthCal.add(Calendar.MONTH, 1)
            refreshMonthLabel()
        }

        viewModel.monthSummary.observe(viewLifecycleOwner) { summary ->
            summaryAdapter.submitList(summary)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
