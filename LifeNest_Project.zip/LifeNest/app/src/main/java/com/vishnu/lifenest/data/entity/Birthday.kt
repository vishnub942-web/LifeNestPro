package com.vishnu.lifenest.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "birthdays")
data class Birthday(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val date: String   // "MM-dd" format, e.g. "07-15" (year not needed for yearly countdown)
)
