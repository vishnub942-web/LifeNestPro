package com.vishnu.lifenest.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.vishnu.lifenest.data.entity.Birthday

@Dao
interface BirthdayDao {

    @Query("SELECT * FROM birthdays ORDER BY date ASC")
    fun getAll(): LiveData<List<Birthday>>

    @Insert
    suspend fun insert(birthday: Birthday)

    @Delete
    suspend fun delete(birthday: Birthday)
}
