package com.vishnu.lifenest.ui.todo

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.vishnu.lifenest.data.AppDatabase
import com.vishnu.lifenest.data.entity.TodoItem
import kotlinx.coroutines.launch

class TodoViewModel(application: Application) : AndroidViewModel(application) {

    private val todoDao = AppDatabase.getDatabase(application).todoDao()
    val allItems: LiveData<List<TodoItem>> = todoDao.getAll()

    fun addItem(text: String) {
        viewModelScope.launch { todoDao.insert(TodoItem(text = text)) }
    }

    fun toggleDone(item: TodoItem) {
        viewModelScope.launch { todoDao.update(item.copy(isDone = !item.isDone)) }
    }

    fun deleteItem(item: TodoItem) {
        viewModelScope.launch { todoDao.delete(item) }
    }
}
