package com.vishnu.lifenest.ui.birthday

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.vishnu.lifenest.data.AppDatabase
import com.vishnu.lifenest.data.entity.Birthday
import kotlinx.coroutines.launch
import java.util.*

// A birthday paired with days remaining until it next occurs
data class BirthdayWithCountdown(
    val birthday: Birthday,
    val daysLeft: Int
)

class BirthdayViewModel(application: Application) : AndroidViewModel(application) {

    private val birthdayDao = AppDatabase.getDatabase(application).birthdayDao()

    val allBirthdaysSorted: LiveData<List<BirthdayWithCountdown>> =
        androidx.lifecycle.Transformations.map(birthdayDao.getAll()) { list ->
            list.map { BirthdayWithCountdown(it, daysUntilNext(it.date)) }
                .sortedBy { it.daysLeft }
        }

    fun addBirthday(name: String, monthDayStr: String) {
        viewModelScope.launch {
            birthdayDao.insert(Birthday(name = name, date = monthDayStr))
        }
    }

    fun deleteBirthday(birthday: Birthday) {
        viewModelScope.launch { birthdayDao.delete(birthday) }
    }

    // date is stored as "MM-dd". Calculates days remaining until next occurrence.
    private fun daysUntilNext(monthDay: String): Int {
        val parts = monthDay.split("-")
        val month = parts[0].toInt()
        val day = parts[1].toInt()

        val today = Calendar.getInstance()
        today.set(Calendar.HOUR_OF_DAY, 0)
        today.set(Calendar.MINUTE, 0)
        today.set(Calendar.SECOND, 0)
        today.set(Calendar.MILLISECOND, 0)

        val next = Calendar.getInstance()
        next.set(Calendar.MONTH, month - 1)
        next.set(Calendar.DAY_OF_MONTH, day)
        next.set(Calendar.HOUR_OF_DAY, 0)
        next.set(Calendar.MINUTE, 0)
        next.set(Calendar.SECOND, 0)
        next.set(Calendar.MILLISECOND, 0)

        if (next.before(today) || next == today) {
            next.add(Calendar.YEAR, 1)
        }

        val diffMillis = next.timeInMillis - today.timeInMillis
        return (diffMillis / (1000 * 60 * 60 * 24)).toInt()
    }
}
