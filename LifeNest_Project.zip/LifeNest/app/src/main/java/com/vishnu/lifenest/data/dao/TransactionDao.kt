package com.vishnu.lifenest.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.vishnu.lifenest.data.entity.Transaction

@Dao
interface TransactionDao {

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun getAll(): LiveData<List<Transaction>>

    @Insert
    suspend fun insert(transaction: Transaction)

    @Delete
    suspend fun delete(transaction: Transaction)
}
