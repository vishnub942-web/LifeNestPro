package com.vishnu.lifenest.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val time: String = "",          // e.g. "06:00 am" - manual text
    val date: String,               // e.g. "2026-07-15"
    val isDone: Boolean = false,
    val remark: String = ""
)
