# LifeNest - Setup & APK Build Instructions

## 📱 Phone മാത്രം ഉള്ളവർക്ക് - GitHub വഴി APK Build ചെയ്യാം (Computer വേണ്ട!)

### Step 1: GitHub Account ഉണ്ടാക്കുക
- Phone browser-ൽ **github.com** പോയി free account ഉണ്ടാക്കുക

### Step 2: New Repository ഉണ്ടാക്കുക
1. GitHub-ൽ login ചെയ്ത ശേഷം **+** icon → **New repository**
2. Name: `LifeNest` (എന്തും ആകാം)
3. **Public** select ചെയ്യുക → **Create repository**

### Step 3: Project Files Upload ചെയ്യുക
1. പുതിയ repo page-ൽ **"uploading an existing file"** link ക്ലിക്ക് ചെയ്യുക
2. ഈ zip file extract ചെയ്ത്, **എല്ലാ files/folders ഉം** (LifeNest folder-ന് അകത്തുള്ളത്) select ചെയ്ത് upload ചെയ്യുക
   - ⚠️ Mobile browser-ൽ zip extract ചെയ്യാൻ ബുദ്ധിമുട്ടാണെങ്കിൽ, **"Files"/"ZArchiver"** പോലുള്ള file manager app ഉപയോഗിച്ച് extract ചെയ്യാം
3. താഴെ **Commit changes** ക്ലിക്ക് ചെയ്യുക

### Step 4: Automatic Build നടക്കും
- Upload കഴിഞ്ഞാൽ, repo-യുടെ **Actions** tab ക്ലിക്ക് ചെയ്യുക
- "Build APK" workflow run ആകുന്നത് കാണാം (2-5 minutes എടുക്കും)
- പച്ച ✅ ആയാൽ build success

### Step 5: APK Download ചെയ്യുക
1. Success ആയ run-ൽ ക്ലിക്ക് ചെയ്യുക
2. താഴെ **Artifacts** section-ൽ **LifeNest-debug-apk** കാണും
3. അത് ക്ലിക്ക് ചെയ്ത് download ചെയ്യുക (ഇത് ഒരു zip ആയിരിക്കും, അതിനകത്ത് APK ഉണ്ട്)
4. Zip extract ചെയ്ത് APK file phone-ൽ install ചെയ്യുക ("Unknown apps" permission വേണ്ടിവരും)

---

## 💻 Computer ഉള്ളവർക്ക് - Android Studio വഴി

## 1. Android Studio Install ചെയ്യുക (ഇല്ലെങ്കിൽ)
https://developer.android.com/studio - download ചെയ്ത് install ചെയ്യുക.

## 2. Project Open ചെയ്യുക
1. Android Studio open ചെയ്യുക
2. **Open** ക്ലിക്ക് ചെയ്യുക (New Project അല്ല)
3. Zip extract ചെയ്ത `LifeNest` folder select ചെയ്യുക
4. "Trust Project" ചോദിച്ചാൽ **Trust** ക്ലിക്ക് ചെയ്യുക

## 3. Gradle Sync (Automatic)
- Project open ആകുമ്പോൾ താഴെ ഒരു progress bar കാണും ("Gradle Sync")
- ഇത് **internet connection** ആവശ്യമാണ് (dependencies download ചെയ്യാൻ)
- 2-10 minutes എടുക്കും (ആദ്യമായി ആണെങ്കിൽ കൂടുതൽ സമയം)
- Error വന്നാൽ "Try Again" ക്ലിക്ക് ചെയ്യുക, അല്ലെങ്കിൽ error message copy ചെയ്ത് എന്നോട് ചോദിക്കൂ

## 4. APK Build ചെയ്യുക
Sync പൂർത്തിയായി കഴിഞ്ഞാൽ:
1. Top menu-ൽ **Build** ക്ലിക്ക് ചെയ്യുക
2. **Build Bundle(s) / APK(s)** → **Build APK(s)** select ചെയ്യുക
3. താഴെ right corner-ൽ "locate" link വരും - അത് ക്ലിക്ക് ചെയ്താൽ APK file folder തുറക്കും
4. APK path: `app/build/outputs/apk/debug/app-debug.apk`

## 5. Phone-ൽ Install ചെയ്യുക
- APK file phone-ലേക്ക് copy ചെയ്യുക (USB / WhatsApp / Google Drive വഴി)
- Phone-ൽ file open ചെയ്ത് install ചെയ്യുക
- "Unknown apps" permission ചോദിച്ചാൽ allow ചെയ്യുക

## App-ന്റെ Features
| Screen | എന്ത് ചെയ്യും |
|--------|---------------|
| Home | Daily task tracker - task, time, ✅/❌ status, remark |
| Calendar | ഏതെങ്കിലും date select ചെയ്ത് ആ ദിവസത്തെ tasks കാണാം + month summary (X/30 days) |
| To-Do | One-time tasks checklist |
| Notepad | Free notes എഴുതാം |
| More → Birthday | Birthday + countdown |
| More → Debit/Credit | കടം/കൊടുക്കാനുള്ളത് track ചെയ്യാം |

## എന്തെങ്കിലും Error വന്നാൽ
Error message (red text) മുഴുവൻ copy ചെയ്ത് എന്നോട് അയക്കൂ, ഞാൻ fix ചെയ്ത് തരാം.
