package com.vishnu.lifenest.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.vishnu.lifenest.data.entity.Note

@Dao
interface NoteDao {

    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun getAll(): LiveData<List<Note>>

    @Insert
    suspend fun insert(note: Note): Long

    @Update
    suspend fun update(note: Note)

    @Delete
    suspend fun delete(note: Note)
}
