package com.vishnu.lifenest.ui.calendar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.vishnu.lifenest.data.AppDatabase
import com.vishnu.lifenest.data.entity.Task
import kotlinx.coroutines.launch
import java.util.*

// Summary of one task's completion across a month, e.g. "18/30 days"
data class TaskMonthSummary(
    val taskName: String,
    val doneCount: Int,
    val totalCount: Int
)

class CalendarViewModel(application: Application) : AndroidViewModel(application) {

    private val taskDao = AppDatabase.getDatabase(application).taskDao()

    private val _selectedDateTasks = MutableLiveData<List<Task>>()
    val selectedDateTasks: LiveData<List<Task>> = _selectedDateTasks

    private val _monthSummary = MutableLiveData<List<TaskMonthSummary>>()
    val monthSummary: LiveData<List<TaskMonthSummary>> = _monthSummary

    // date format expected: "yyyy-MM-dd"
    fun loadTasksForDate(date: String) {
        viewModelScope.launch {
            _selectedDateTasks.value = taskDao.getTasksForMonth(date.substring(0, 7))
                .filter { it.date == date }
        }
    }

    // monthPrefix format: "yyyy-MM", e.g. "2026-07"
    fun loadMonthSummary(monthPrefix: String) {
        viewModelScope.launch {
            val tasks = taskDao.getTasksForMonth(monthPrefix)
            val daysInMonth = daysInMonth(monthPrefix)

            val summary = tasks
                .groupBy { it.name }
                .map { (name, list) ->
                    TaskMonthSummary(
                        taskName = name,
                        doneCount = list.count { it.isDone },
                        totalCount = daysInMonth
                    )
                }
                .sortedBy { it.taskName }

            _monthSummary.value = summary
        }
    }

    private fun daysInMonth(monthPrefix: String): Int {
        val parts = monthPrefix.split("-")
        val year = parts[0].toInt()
        val month = parts[1].toInt()
        val cal = Calendar.getInstance()
        cal.set(year, month - 1, 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }
}
