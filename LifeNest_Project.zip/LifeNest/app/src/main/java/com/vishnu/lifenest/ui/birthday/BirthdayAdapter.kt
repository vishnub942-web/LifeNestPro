package com.vishnu.lifenest.ui.birthday

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.vishnu.lifenest.databinding.ItemBirthdayBinding

class BirthdayAdapter(
    private val onDelete: (BirthdayWithCountdown) -> Unit
) : ListAdapter<BirthdayWithCountdown, BirthdayAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBirthdayBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.binding.tvName.text = item.birthday.name
        holder.binding.tvCountdown.text = if (item.daysLeft == 0)
            "🎉 Today!"
        else
            "${item.daysLeft} days left"
        holder.binding.btnDelete.setOnClickListener { onDelete(item) }
    }

    class ViewHolder(val binding: ItemBirthdayBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<BirthdayWithCountdown>() {
            override fun areItemsTheSame(oldItem: BirthdayWithCountdown, newItem: BirthdayWithCountdown) =
                oldItem.birthday.id == newItem.birthday.id
            override fun areContentsTheSame(oldItem: BirthdayWithCountdown, newItem: BirthdayWithCountdown) =
                oldItem == newItem
        }
    }
}
