package com.vishnu.lifenest.ui.todo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.vishnu.lifenest.databinding.FragmentTodoBinding

class TodoFragment : Fragment() {

    private var _binding: FragmentTodoBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TodoViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = TodoAdapter(
            onToggle = { viewModel.toggleDone(it) },
            onDelete = { viewModel.deleteItem(it) }
        )
        binding.recyclerTodo.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerTodo.adapter = adapter

        viewModel.allItems.observe(viewLifecycleOwner) { adapter.submitList(it) }

        binding.btnAdd.setOnClickListener {
            val text = binding.etNewItem.text.toString().trim()
            if (text.isNotEmpty()) {
                viewModel.addItem(text)
                binding.etNewItem.text.clear()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
