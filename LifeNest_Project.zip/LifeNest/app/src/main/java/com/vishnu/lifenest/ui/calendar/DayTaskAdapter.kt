package com.vishnu.lifenest.ui.calendar

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.vishnu.lifenest.data.entity.Task
import com.vishnu.lifenest.databinding.ItemDayTaskBinding

class DayTaskAdapter : ListAdapter<Task, DayTaskAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDayTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val task = getItem(position)
        holder.binding.tvName.text = task.name
        holder.binding.tvStatus.text = if (task.isDone) "✅" else "❌"
        holder.binding.tvTime.text = task.time
        holder.binding.tvRemark.text = task.remark
    }

    class ViewHolder(val binding: ItemDayTaskBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Task>() {
            override fun areItemsTheSame(oldItem: Task, newItem: Task) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Task, newItem: Task) = oldItem == newItem
        }
    }
}
