package com.vishnu.lifenest.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.vishnu.lifenest.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvDate.text = "Today: ${viewModel.todayDate}"

        val adapter = TaskAdapter(
            onToggleDone = { task -> viewModel.toggleDone(task) },
            onTimeChanged = { task, time -> viewModel.updateTime(task, time) },
            onRemarkChanged = { task, remark -> viewModel.updateRemark(task, remark) },
            onDelete = { task -> viewModel.deleteTaskEverywhere(task) }
        )

        binding.recyclerTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerTasks.adapter = adapter

        viewModel.tasksToday.observe(viewLifecycleOwner) { tasks ->
            adapter.submitList(tasks)
        }

        binding.fabAddTask.setOnClickListener {
            val input = android.widget.EditText(requireContext())
            input.hint = "Task name"
            android.app.AlertDialog.Builder(requireContext())
                .setTitle("Add New Task")
                .setView(input)
                .setPositiveButton("Add") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotEmpty()) viewModel.addTask(name)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
