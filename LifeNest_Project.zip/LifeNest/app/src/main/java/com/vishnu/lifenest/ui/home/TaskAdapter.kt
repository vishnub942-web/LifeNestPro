package com.vishnu.lifenest.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.vishnu.lifenest.data.entity.Task
import com.vishnu.lifenest.databinding.ItemTaskRowBinding

class TaskAdapter(
    private val onToggleDone: (Task) -> Unit,
    private val onTimeChanged: (Task, String) -> Unit,
    private val onRemarkChanged: (Task, String) -> Unit,
    private val onDelete: (Task) -> Unit
) : ListAdapter<Task, TaskAdapter.TaskViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TaskViewHolder(private val binding: ItemTaskRowBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(task: Task) {
            binding.tvTaskName.text = task.name
            binding.etTime.setText(task.time)
            binding.etRemark.setText(task.remark)
            binding.btnStatus.text = if (task.isDone) "✅" else "❌"

            binding.btnStatus.setOnClickListener { onToggleDone(task) }
            binding.btnDelete.setOnClickListener { onDelete(task) }

            // Save time/remark only when the field loses focus (avoids saving on every keystroke)
            binding.etTime.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) onTimeChanged(task, binding.etTime.text.toString())
            }
            binding.etRemark.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) onRemarkChanged(task, binding.etRemark.text.toString())
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Task>() {
            override fun areItemsTheSame(oldItem: Task, newItem: Task) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Task, newItem: Task) = oldItem == newItem
        }
    }
}
