package com.vishnu.lifenest.ui.todo

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.vishnu.lifenest.data.entity.TodoItem
import com.vishnu.lifenest.databinding.ItemTodoBinding

class TodoAdapter(
    private val onToggle: (TodoItem) -> Unit,
    private val onDelete: (TodoItem) -> Unit
) : ListAdapter<TodoItem, TodoAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTodoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.binding.cbDone.setOnCheckedChangeListener(null)
        holder.binding.cbDone.isChecked = item.isDone
        holder.binding.tvText.text = item.text
        holder.binding.tvText.paintFlags = if (item.isDone)
            holder.binding.tvText.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        else
            holder.binding.tvText.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()

        holder.binding.cbDone.setOnCheckedChangeListener { _, _ -> onToggle(item) }
        holder.binding.btnDelete.setOnClickListener { onDelete(item) }
    }

    class ViewHolder(val binding: ItemTodoBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<TodoItem>() {
            override fun areItemsTheSame(oldItem: TodoItem, newItem: TodoItem) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: TodoItem, newItem: TodoItem) = oldItem == newItem
        }
    }
}
