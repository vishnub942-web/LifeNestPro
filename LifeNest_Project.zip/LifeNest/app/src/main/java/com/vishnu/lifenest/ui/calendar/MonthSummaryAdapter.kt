package com.vishnu.lifenest.ui.calendar

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.vishnu.lifenest.databinding.ItemMonthSummaryBinding

class MonthSummaryAdapter : ListAdapter<TaskMonthSummary, MonthSummaryAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMonthSummaryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.binding.tvTaskName.text = item.taskName
        holder.binding.tvCount.text = "${item.doneCount}/${item.totalCount} days ✅"
    }

    class ViewHolder(val binding: ItemMonthSummaryBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<TaskMonthSummary>() {
            override fun areItemsTheSame(oldItem: TaskMonthSummary, newItem: TaskMonthSummary) =
                oldItem.taskName == newItem.taskName
            override fun areContentsTheSame(oldItem: TaskMonthSummary, newItem: TaskMonthSummary) =
                oldItem == newItem
        }
    }
}
