package com.vishnu.lifenest.ui.notepad

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.vishnu.lifenest.databinding.FragmentNotepadBinding

class NotepadFragment : Fragment() {

    private var _binding: FragmentNotepadBinding? = null
    private val binding get() = _binding!!
    private val viewModel: NotepadViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotepadBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = NoteAdapter(onDelete = { viewModel.deleteNote(it) })
        binding.recyclerNotes.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerNotes.adapter = adapter

        viewModel.allNotes.observe(viewLifecycleOwner) { adapter.submitList(it) }

        binding.fabAddNote.setOnClickListener {
            val dialogView = LayoutInflater.from(requireContext())
                .inflate(com.vishnu.lifenest.R.layout.dialog_new_note, null)
            val etTitle = dialogView.findViewById<android.widget.EditText>(com.vishnu.lifenest.R.id.etNoteTitle)
            val etContent = dialogView.findViewById<android.widget.EditText>(com.vishnu.lifenest.R.id.etNoteContent)

            android.app.AlertDialog.Builder(requireContext())
                .setTitle("New Note")
                .setView(dialogView)
                .setPositiveButton("Save") { _, _ ->
                    viewModel.saveNote(etTitle.text.toString(), etContent.text.toString())
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
