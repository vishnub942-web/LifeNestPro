package com.vishnu.lifenest.ui.birthday

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.vishnu.lifenest.databinding.FragmentBirthdayBinding
import java.util.*

class BirthdayFragment : Fragment() {

    private var _binding: FragmentBirthdayBinding? = null
    private val binding get() = _binding!!
    private val viewModel: BirthdayViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBirthdayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = BirthdayAdapter(onDelete = { viewModel.deleteBirthday(it.birthday) })
        binding.recyclerBirthdays.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerBirthdays.adapter = adapter

        viewModel.allBirthdaysSorted.observe(viewLifecycleOwner) { adapter.submitList(it) }

        binding.fabAddBirthday.setOnClickListener {
            val nameInput = android.widget.EditText(requireContext())
            nameInput.hint = "Name"

            android.app.AlertDialog.Builder(requireContext())
                .setTitle("Add Birthday - Name")
                .setView(nameInput)
                .setPositiveButton("Next: Pick Date") { _, _ ->
                    val name = nameInput.text.toString().trim()
                    if (name.isNotEmpty()) showDatePicker(name)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun showDatePicker(name: String) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            requireContext(),
            { _, _, month, dayOfMonth ->
                val monthDayStr = String.format("%02d-%02d", month + 1, dayOfMonth)
                viewModel.addBirthday(name, monthDayStr)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
