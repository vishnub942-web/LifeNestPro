package com.vishnu.lifenest.ui.debitcredit

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.vishnu.lifenest.data.entity.Transaction
import com.vishnu.lifenest.databinding.ItemTransactionBinding

class TransactionAdapter(
    private val onDelete: (Transaction) -> Unit
) : ListAdapter<Transaction, TransactionAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val t = getItem(position)
        holder.binding.tvPersonName.text = t.personName
        holder.binding.tvDate.text = t.date
        holder.binding.tvRemark.text = t.remark
        val sign = if (t.type == "CREDIT") "+" else "-"
        holder.binding.tvAmount.text = "$sign${t.amount}"
        holder.binding.tvAmount.setTextColor(
            if (t.type == "CREDIT") 0xFF2E7D32.toInt() else 0xFFC62828.toInt()
        )
        holder.binding.btnDelete.setOnClickListener { onDelete(t) }
    }

    class ViewHolder(val binding: ItemTransactionBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Transaction>() {
            override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction) = oldItem == newItem
        }
    }
}
