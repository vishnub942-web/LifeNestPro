package com.vishnu.lifenest.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.vishnu.lifenest.data.entity.TodoItem

@Dao
interface TodoDao {

    @Query("SELECT * FROM todo_items ORDER BY createdAt DESC")
    fun getAll(): LiveData<List<TodoItem>>

    @Insert
    suspend fun insert(item: TodoItem)

    @Update
    suspend fun update(item: TodoItem)

    @Delete
    suspend fun delete(item: TodoItem)
}
