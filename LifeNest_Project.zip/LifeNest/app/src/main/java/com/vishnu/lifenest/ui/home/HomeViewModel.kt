package com.vishnu.lifenest.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.vishnu.lifenest.data.AppDatabase
import com.vishnu.lifenest.data.entity.Task
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val taskDao = AppDatabase.getDatabase(application).taskDao()

    // today's date, e.g. "2026-07-15"
    val todayDate: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    val tasksToday: LiveData<List<Task>> = taskDao.getTasksForDate(todayDate)

    init {
        // Every time Home opens, make sure today's row exists for every
        // routine task name that was used before (so tasks repeat daily).
        ensureTodayRowsExist()
    }

    private fun ensureTodayRowsExist() {
        viewModelScope.launch {
            val allNames = taskDao.getAllTaskNamesOnce()
            for (name in allNames) {
                val existing = taskDao.findByNameAndDate(name, todayDate)
                if (existing == null) {
                    taskDao.insert(Task(name = name, date = todayDate))
                }
            }
        }
    }

    fun toggleDone(task: Task) {
        viewModelScope.launch {
            taskDao.update(task.copy(isDone = !task.isDone))
        }
    }

    fun updateRemark(task: Task, remark: String) {
        viewModelScope.launch {
            taskDao.update(task.copy(remark = remark))
        }
    }

    fun updateTime(task: Task, time: String) {
        viewModelScope.launch {
            taskDao.update(task.copy(time = time))
        }
    }

    // Adds a brand-new task name. Because tasks repeat daily, we only add
    // it for today; CalendarViewModel will look at task "name" history separately.
    fun addTask(name: String) {
        viewModelScope.launch {
            val existing = taskDao.findByNameAndDate(name, todayDate)
            if (existing == null) {
                taskDao.insert(Task(name = name, date = todayDate))
            }
        }
    }

    // Deletes this task everywhere (all days), since it's removed from the routine.
    fun deleteTaskEverywhere(task: Task) {
        viewModelScope.launch {
            taskDao.deleteAllWithName(task.name)
        }
    }
}
